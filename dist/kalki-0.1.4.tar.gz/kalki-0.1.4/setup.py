from setuptools import setup, find_packages

setup(
    name="kalki",
    version="0.1.4",
    description="Kalki is a library to create dynamic CSS",
    author="Biswajit Bimoli",
    packages=['kalki'],
    readme = "README.md",
    author_email='biswajitbimoli@gmail.com',
    url='https://github.com/biswajitbimoli/kalki',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries',
    ],
    entry_points={
        'console_scripts': [
            'kalki = bin.kalki:startproject'],
    },
    include_package_data=True,
)