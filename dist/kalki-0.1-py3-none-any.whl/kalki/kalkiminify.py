from kalki.minify.minify import Minify

def kalkiminify(appname):
    Minify(appname).minify()

