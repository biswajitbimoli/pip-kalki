# Kalki

A small library to create dynamic CSS

follow link for Usage: https://github.com/biswajitbimoli/kalki